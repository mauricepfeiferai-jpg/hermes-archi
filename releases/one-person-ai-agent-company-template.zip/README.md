# One-Person AI Agent Company Template

## What's Inside

- `ceo/` — CEO agent role, job description, daily goals
- `cto/` — CTO agent role, tech health checks
- `engineer/` — Engineer agent role, backlog + shipping
- `researcher/` — Research agent role, daily briefs
- `writer/` — Writer agent role, content engine
- `sales/` — Sales agent role, pipeline + outbound
- `ops/` — Ops agent role, cron jobs, backups, health
- `loop/` — Review, retro, and self-improvement loop

## Quick Start

1. Copy this folder into your project as `ai-company/`.
2. Read `README.md` inside the template.
3. Install the crontab: `cat ops/cron/crontab.txt | crontab -`
4. Run one manual cycle: `bash ops/cron/06-ceo-daily-goals.sh` etc.
5. Review outputs in `*/outputs/`.

## Professional Tier Includes

- Hermes skill wiring via `ops/cron/run_agent.py`
- BMA service-business variant in `variants/bma-service-company/`
- 30-minute setup video

## Support

For questions, email maurice@aiempire.de or DM @mauricepfeifer on X.
