# One-Person AI Agent Company Template

## What's Inside

- `ceo/` — CEO agent role, job description, decision log
- `cto/` — CTO agent role, architecture review, tech radar
- `engineer/` — Engineer agent role, implementation patterns
- `researcher/` — Research agent role, research briefs and sources
- `writer/` — Writer agent role, content engine templates
- `sales/` — Sales agent role, outreach and lead tracking
- `ops/` — Ops agent role, cron jobs, monitoring, backups
- `loop/` — Review, retro, and self-improvement templates

## Quick Start

1. Copy this folder into your project as `ai-company/`.
2. Adapt each `README.md` to your business context.
3. Wire the roles into your Hermes runtime or favorite agent framework.
4. Schedule the cron jobs from `ops/cron/`.
5. Run the loop: execute → review → retro → patch → repeat.

## Professional Tier Includes

- Hermes skill wiring
- BMA service-business variant
- 30-minute setup video

## Support

For questions, email maurice@aiempire.de or DM @mauricepfeifer on X.
